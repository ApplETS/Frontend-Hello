export default function Dashboard() {
  return <p>Test</p>;
}
